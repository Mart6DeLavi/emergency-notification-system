package com.sensa.usermanagementservice.model;

public enum Gender {
    MALE, FEMALE
}
