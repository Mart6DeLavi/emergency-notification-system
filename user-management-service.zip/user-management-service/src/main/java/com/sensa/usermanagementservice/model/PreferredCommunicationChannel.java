package com.sensa.usermanagementservice.model;

public enum PreferredCommunicationChannel {
    EMAIL, SMS
}
