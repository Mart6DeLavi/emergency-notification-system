package com.sensa.usermanagementservice.model;

public enum Role {
    ADMIN, USER
}
