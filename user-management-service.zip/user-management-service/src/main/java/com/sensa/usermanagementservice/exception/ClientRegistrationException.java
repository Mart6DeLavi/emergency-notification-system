package com.sensa.usermanagementservice.exception;

public class ClientRegistrationException extends RuntimeException {
    public ClientRegistrationException(String message) {
        super(message);
    }
}
